from snorkel.preprocess.nlp import SpacyPreprocessor
from snorkel.labeling.model import LabelModel
from snorkel.labeling import LabelingFunction
from snorkel.labeling import PandasLFApplier
from .searchTools import FunctionCreator
from snorkel.labeling import LFAnalysis
from .searchTools import SearchTools


import pandas as pd
import numpy as np

class WeakFunctionPreProcess:
    
    def __init__(self, spacyProcessor: SpacyPreprocessor = None) -> None:
        self.spacy = spacyProcessor
    
    def get_search_function(self, textColumnName: str,
                            typeSerach: str,
                            actuaLabel: int,
                            keywordsList: list) -> LabelingFunction:
        if typeSerach == "clave_porcentaje":
            return FunctionCreator.make_keyword_percentage_lf(functionName=keywordsList[0],
                                                          keywordsList=keywordsList,
                                                          label=actuaLabel,
                                                          textColumnName=textColumnName)
        elif typeSerach == "clave_fecha":
            return FunctionCreator.make_keyword_date_lf(functionName=keywordsList[0],
                                                    keywordsList=keywordsList,      
                                                    label=actuaLabel,
                                                    textColumnName=textColumnName)
        elif typeSerach == "clave":
            return FunctionCreator.make_keyword_lf(functionName=keywordsList[0],
                                               keywordsList=keywordsList,      
                                               label=actuaLabel,
                                               textColumnName=textColumnName)
            
        elif typeSerach == "documento-id":
            return FunctionCreator.make_keyword_lf(functionName=keywordsList[0],
                                               keywordsList=keywordsList,      
                                               label=actuaLabel,
                                               textColumnName=textColumnName)
            
            
    def get_generic_functions(self, keyWordDictionary: dict,
                                    textColumnName: str = "text_pages") -> object:
        functionsList = []
        functionsDict = {}
        actual_label = 0
        for typeSearch, keywordsList in keyWordDictionary.items():
            if typeSearch != "funciones_especificas":
                for keywords in keywordsList:
                  actual_label += 1
                  searchFunction = self.get_search_function(textColumnName=textColumnName,
                                                            typeSerach=typeSearch,
                                                            actuaLabel=actual_label,
                                                            keywordsList=keywords)
                  functionsList.append(searchFunction)
                  functionsDict[actual_label] = keywords[0]

        functionsDict[-1] = "sin info"
        return functionsList, functionsDict
    
    
    def __get_spacy_processor(self, textFielCoulmn: str = "text_pages"):
        if self.spacy is None:
            self.spacy = SpacyPreprocessor(text_field=textFielCoulmn, doc_field="doc",
                                  memoize=True, language="es_core_news_lg")
        return self.spacy
    
    
    
    
    def __get_specific_function(self, requeriedFunction,
                                label: int,
                                textFielCoulmn: str = "text_pages") -> object:
        
        spacy = self.__get_spacy_processor(textFielCoulmn)
        spacy.reset_cache()
        

            
        functionsDict = {
        "check_person": SearchTools.return_check_person_function(spacyProcessor=spacy,
                                                                    textFielCoulmn=textFielCoulmn,
                                                                    label=label),
        "check_place": SearchTools.return_check_place_function(spacyProcessor=spacy,
                                                                textFielCoulmn=textFielCoulmn,
                                                                label=label),
        
        "check_money": SearchTools.return_check_money_function(spacyProcessor=spacy,
                                                                textFielCoulmn=textFielCoulmn,
                                                                label=label),
        "check_organization": SearchTools.return_check_organization_function(spacyProcessor=spacy,
                                                                                textFielCoulmn=textFielCoulmn,
                                                                                label=label),
        
        "check_org_id": SearchTools.return_check_org_id_completed(spacyProcessor=spacy,
                                                                    textFielCoulmn=textFielCoulmn,
                                                                    label=label),
        
        "check_person_id": SearchTools.return_check_completed_person_id(spacyProcessor=spacy,
                                                                    textFielCoulmn=textFielCoulmn,
                                                                    label=label)

        }
            
          
        return functionsDict.get(requeriedFunction)
    
    
    def get_total_functions(self,keyWordDictionary: dict,
                            textColumnName: str = "parraph_text") -> object:

        toAddFunctions = []
        functionsList, functionsDict = self.get_generic_functions(keyWordDictionary=keyWordDictionary,
                                                                  textColumnName=textColumnName)
        
        functionsToAggregate = keyWordDictionary.get("funciones_especificas", None)
        if functionsToAggregate:
            maxLabel = max(functionsDict.keys())
            for espfn in functionsToAggregate:
                maxLabel += 1
                selectedFunction = self.__get_specific_function(requeriedFunction=espfn,
                                                                label=maxLabel,
                                                                textFielCoulmn=textColumnName)
                toAddFunctions.append(selectedFunction)
                functionsDict[maxLabel] = espfn
            
            functionsList.extend(toAddFunctions)
        
        cleanedList = [i for i in functionsList if i]
        return functionsDict, cleanedList
    
    
    


class WeakFunctionPrediction:
    def __init__(self):
        pass
    
    def get_labeled_matrix(self,listLabelFunctionss: list,
                           trainDataFrame: pd.DataFrame,
                           verbose: bool = True) -> np.matrix:
        self.numberFunctions = len(listLabelFunctionss)
        applier = PandasLFApplier(lfs=listLabelFunctionss)
        L_train = applier.apply(trainDataFrame)
        if verbose:
            print(LFAnalysis(L_train).lf_summary())
        return L_train


    def get_prediction_array(self, labeledMatrix: np.matrix,
                             cardinality: int = None,
                              **kargs):
        if cardinality:
            self.numberFunctions = kargs.get("cardinality", None)
        label_model = LabelModel(cardinality=self.numberFunctions, verbose=True)
        label_model.fit(L_train=labeledMatrix, n_epochs=kargs.get("nPochs", 1000), log_freq=kargs.get("logFreq", 100), seed=kargs.get("seed", 123))
        return label_model.predict(labeledMatrix, tie_break_policy=kargs.get("breakPolicy", "random"))

    def get_predicrion_dataframe(self,listLabelFunctionss:list,
                              trainDataFrame: pd.DataFrame,
                              **kargs):
        labeledMatrix = self.get_labeled_matrix(listLabelFunctionss=listLabelFunctionss,
                                      trainDataFrame=trainDataFrame)
        arrayPrediction = self.get_prediction_array(labeledMatrix=labeledMatrix,
                                           cardinality=kargs.get("cardinality", None),
                                          nPochs=kargs.get("nPochs", 1000),
                                          logFreq=kargs.get("logFreq", 100),
                                          seed=kargs.get("seed", 123),
                                          breakPolicy=kargs.get("breakPolicy", "random"))
        trainDataFrame["prediction"] = arrayPrediction
        return trainDataFrame