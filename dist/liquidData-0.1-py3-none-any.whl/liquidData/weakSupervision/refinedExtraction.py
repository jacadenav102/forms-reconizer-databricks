import databricks.koalas as ks
import es_core_news_lg
import re

class TermsExtractionProcess:


    def __init__(self) -> None:
        pass

    def get_sentencers_list(self, text: str,
                            spacyPipelines: object = None) -> list:
        if spacyPipelines:
            nlp = spacyPipelines
        else:
            nlp = es_core_news_lg.load()
        doc = nlp(text)
        return [sent for sent in doc.sents]

    
    def get_specific_searched_value(self, sentence: object, firstCondition: str,
                                    secondCondition: str, patternList: list) -> str:

        posibleValues = []
        for idx, token in enumerate(sentence):
            if token.text.lower() == firstCondition:
                try:
                    if secondCondition in [token.nbor(1).text,  token.nbor(2).text.lower()]:
                        string = sentence[idx: ].text.lower()
                    for pattern in patternList:
                        regexProff = re.search(pattern, string)
                        if regexProff:
                            posibleValues.append(regexProff.group(0))   
                except:
                    pass

        if posibleValues:
            return posibleValues[0]
        else:
            return None
        
        
    def get_searched_value_list(self, text: str,
                            firstCondition: str,
                            secondCondition: str,
                            patternList: list) -> object:
        resultList = []
        correctSentences = []
        sentencesList = self.get_sentencers_list(text)
        for sentence in sentencesList:
            foundValue = self.get_specific_searched_value(sentence, firstCondition, secondCondition, patternList)
            if foundValue:
                resultList.append(foundValue)
                correctSentences.append(sentence.text)
        
        return correctSentences,  resultList

    def extract_terms_by_pattern(self,formsData: ks.DataFrame,
                                firstCondition: str,
                                secondCondition:str,
                                **kargs) -> dict:
        formsData = formsData.reset_index()
        pageNumberList = []
        keyList = []
        parraphNumbersList = []
        correctSenList = []
        seachCriteriaList = []
        resultList = []
        for idx, text in enumerate(formsData[kargs.get("texColumn", "parraph_text")].to_numpy()):
            pageNumber = formsData.loc[idx, [kargs.get("pageNumberColumn", "page_number")]].values[0]
            key = formsData.loc[idx, [kargs.get("documentKeyColumn", "document_key")]].values[0]
            criteria = formsData.loc[idx, [kargs.get("seachCriteriaColumn", "criterio_busqueda")]].values[0]
            parragpraphNumber = formsData.loc[idx, [kargs.get("parragraphNumberColumn","parragraph_number") ]].values[0]
            correctSentences, result  = self.get_searched_value_list(text, firstCondition, secondCondition, kargs.get("patternList"))
            size = len(correctSentences)
            pageNumberList.extend([pageNumber] * size)
            seachCriteriaList.extend([criteria] * size)
            keyList.extend([key] * size)
            correctSenList.extend(correctSentences)
            parraphNumbersList.extend([parragpraphNumber] * size)
            resultList.extend(result)
        return {"document_key": keyList,
                    "page_number": pageNumberList,
                    "parragraph_number": parraphNumbersList,
                    "search_criteria": seachCriteriaList,
                    "sentences": correctSenList,
                    "result": resultList}
        
        
    def extrac_found_terms_data(self, formsData: ks.DataFrame,
                                firstCondition: str,
                                secondCondition:str,
                                patternList: list,
                                **kargs):
        resultDict = self.extract_terms_by_pattern(formsData=formsData,
                                      firstCondition=firstCondition,
                                      secondCondition=secondCondition,
                                      pageNumberColumn=kargs.get("pageNumberColumn", "page_number"),
                                      documentKeyColumn=kargs.get("documentKeyColumn", "document_key"),
                                      seachCriteriaColumn=kargs.get("seachCriteriaColumn", "criterio_busqueda"),
                                      textColumn=kargs.get("textColumn","parraph_text"),
                                      parragraphNumberColumn=kargs.get("parragraphNumberColumn","parragraph_number"),patternList=patternList)
        
        return ks.DataFrame(resultDict)