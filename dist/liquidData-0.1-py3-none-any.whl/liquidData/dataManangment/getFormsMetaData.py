from databricks.koalas import option_context
import databricks.koalas as ks

import pandas as pd
import datetime
import pathlib
import shutil 
import os


class FormMetadataProcess:
    def __init__(self) -> None:
        pass
    
    
    def get_to_process_directories(self, formsRootPath: str,
                                deltaTime: int = 0,
                                exludeDirectory: list = ["sizerestriction"]) -> list:
        now = datetime.datetime.now()
        directoryList = os.listdir(formsRootPath)
        directorieToProcess = []
        for directory in directoryList:
            completePahtDirectory = os.path.join(formsRootPath, directory)
            fname = pathlib.Path(completePahtDirectory)
            mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
            if (now- mtime).days <= deltaTime:
                directorieToProcess.append(completePahtDirectory)
                
        finalDirectoryList = [directory for directory in directorieToProcess if(directory not in exludeDirectory)]
        return finalDirectoryList
        


    def create_metadata_forms(self, directorieToProcess: list,
                            fileName: str = "file_name",
                            filePath: str = "file_path",
                            directorName: str = "directory_name",
                            ingestionDate: str = "ingestation_date",
                            megaBytesColumns: str = "mega_bytes_size",
                            deltaTime: int = 0) -> pd.DataFrame:

        fileNameList = [] 
        pathFileList = []
        directoryNameList = []
        filesDateList = []
        megaBytesSizeList = []
        now = datetime.datetime.now()
        for directory in directorieToProcess:
            for path, _, files in os.walk(directory):
                for name in files:
                    fileCompletePath = os.path.join(path, name)
                    fname = pathlib.Path(fileCompletePath)
                    mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
                    if (now- mtime).days == deltaTime:
                        if name.endswith("pdf"):
                            modifiedDateFile = datetime.datetime.fromtimestamp(pathlib.Path(fileCompletePath).stat().st_mtime).strftime("%Y/%m/%d %H:%M:%S")
                            megaBytesSize = os.path.getsize(fileCompletePath)/1000000
                            directoryName = "/".join(path.split("/")[4:]) + "/"
                            fileNameList.append(name.strip())
                            megaBytesSizeList.append(megaBytesSize)
                            pathFileList.append(fileCompletePath.strip())
                            directoryNameList.append(directoryName.strip())
                            filesDateList.append(modifiedDateFile.strip())

        infoDict = {
            fileName: fileNameList,
            filePath: pathFileList,
            ingestionDate: filesDateList,
            megaBytesColumns: megaBytesSizeList,
            directorName: directoryNameList

        }

        return pd.DataFrame(infoDict)


    def create_forms_metadata(self, formsPath: str,
                            deltaTime: int = 0,
                            exludeDirectory: list = ["sizerestriction"]) -> pd.DataFrame:
        directorieToProcess= self.get_to_process_directories(formsRootPath = formsPath, deltaTime=deltaTime, exludeDirectory = exludeDirectory)
        if directorieToProcess:
            formsMetaData = self.create_metadata_forms(directorieToProcess)
        else:
            formsMetaData = None
        
        return formsMetaData



    def get_arrive_order(self, formsMetaData: pd.DataFrame,
                        ingestionDate: str = "ingestation_date",
                        directoryName: str = "directory_name",
                        dateFormat: str = "%Y/%m/%d %H:%M:%S"):
        formsMetaData[ingestionDate] = pd.to_datetime(formsMetaData[ingestionDate], format=dateFormat)
        formsMetaData = formsMetaData.sort_values([ingestionDate, directoryName]).reset_index()
        formsMetaData["order_file"] = formsMetaData.groupby(directoryName)[ingestionDate].rank(method='first').astype(int)
        return formsMetaData
        
    def create_forms_key(self, formsMetaData: pd.DataFrame,
                        ingestionDate: str = "ingestation_date",
                        directoryName: str = "directory_name",
                        dateFormat: str = "%Y/%m/%d"):
        
        formsMetaData["key"] = formsMetaData[directoryName] + "_" + formsMetaData[ingestionDate].dt.strftime(dateFormat) + "_" + formsMetaData["order_file"].astype(str)
        formsMetaData = formsMetaData.drop("order_file", axis=1)
        return formsMetaData
        

    def generate_metadata_dataframe(self, formsPath: str,
                                    deltaTime: int = 0,
                                    exludeDirectory: list = ["sizerestriction"]) -> ks.DataFrame:  

        formsMetaData = self.create_forms_metadata(formsPath, deltaTime, exludeDirectory)
        if formsMetaData is not None:
            formsMetaData = self.get_arrive_order(formsMetaData)
            formsMetaData = self.create_forms_key(formsMetaData)
            return ks.from_pandas(formsMetaData)
        else:
            pass



    def move_file(self, sourceFile: str,
                destinationDirectory: str,
                fileName) -> None:
        fullPath = destinationDirectory + fileName
        if pathlib.Path(fullPath).exists() is True:
           os.remove(fullPath)
        if pathlib.Path(sourceFile).exists() is True:
          shutil.move(sourceFile, destinationDirectory, copy_function = shutil.copytree) 

        if pathlib.Path(sourceFile).exists() is True:
            os.remove(fullPath)


    def get_sizes_forms_divition(self, 
                                formsPath: str,
                                sizeColumn: str,
                                limitSize: float,
                                deltaTime: int = 0,
                                exludeDirectory: list = ["sizerestriction"]) -> object:
        toProcess = self.generate_metadata_dataframe(formsPath=formsPath, deltaTime=deltaTime, exludeDirectory=exludeDirectory)
        sizeFilter = toProcess[sizeColumn] < limitSize
        notSizeFilter = toProcess[sizeColumn] > limitSize
        return toProcess.loc[sizeFilter], toProcess.loc[notSizeFilter]
    
    
    def move_bigger_documents(self, toMoveForms: ks.DataFrame,
                              destinationDirectory: str,
                              filesNameColumn: str = "file_name",
                              filePathColumn: str = "file_path")-> None:
        toMoveForms = toMoveForms.reset_index(drop=True)
        for index, file in enumerate(toMoveForms[filesNameColumn].to_numpy()):
            source = toMoveForms.loc[index, [filePathColumn]].to_numpy()[0]
            self.move_file(source, destinationDirectory, file)