from pyspark.sql.functions import collect_list
from pyspark.sql.dataframe import DataFrame 
from pyspark.sql.functions import concat_ws
from pyspark.sql.functions import col
from pyspark.sql import SparkSession 
from spacy.language import Language

import databricks.koalas as ks
import es_core_news_lg
import spacy
import re

class SpacyTools:
  @staticmethod
  @Language.component("correct_final_point")
  def correct_final_point(doc: spacy.tokens.doc.Doc) -> spacy.tokens.doc.Doc:
    compilerOne = re.compile("\.[0-9]*\.([0-9]){3}\.([0-9]){3}\w?")
    compilerTwo = re.compile("(No|no)\.([0-9]*)")
    compilerThree = re.compile("^\.([0-9]*)$")
    compilerFour = re.compile("^[A-Z]\w*")
    for token in doc[:-1]:
        if compilerOne.search((token.text+doc[token.i +1].text).strip()):
            doc[token.i +1].is_sent_start = False
        if compilerTwo.search((token.text+doc[token.i +1].text).strip()):
            doc[token.i +1].is_sent_start = False
        if compilerThree.search((token.text+doc[token.i +1].text).strip()):
            doc[token.i + 1 ].is_sent_start = False
        if not compilerFour.search((token.text).strip().strip()):
            doc[token.i].is_sent_start = False

    return doc

  @staticmethod
  def get_custom_spacy_pipeline() -> object:
    nlp = es_core_news_lg.load()
    nlp.add_pipe("correct_final_point", before='parser')
    nlp.add_pipe("correct_semi_colon", before='parser')
    return nlp

  @staticmethod
  @Language.component("correct_semi_colon")
  def correct_semi_colon(doc: spacy.tokens.doc.Doc):
    for token in doc[:-1]:
      if token.text == ';':
        doc[token.i+1].is_sent_start = True
    return doc


class LinesParrgraphsProcess:
  def __init__(self) -> None:
      pass


  def concatenate_lines_information(self, linesDataFrame: DataFrame,
                                    **kargs) -> ks.DataFrame:
    
    return ks.DataFrame(
                        linesDataFrame
                        .filter(col(kargs.get("textLinesColumn", "text_lines")) != "")
                        .groupBy(col(kargs.get("documentKeyColumn","document_key")), col(kargs.get("pageNumberColumn","page_number")))
                        .agg( concat_ws(" ", collect_list(col(kargs.get("textLinesColumn", "text_lines")))).alias("concatenated_text"))
                        .orderBy(kargs.get("documentKeyColumn","document_key"), kargs.get("pageNumberColumn","page_number"))  )

  def get_parraph_text(self, doc: spacy.tokens.doc.Doc) -> list: 
    pattagraphlist = []
    parragraphsText = ""
    capitalizeCompiler = re.compile("^[A-Z]\w*")
    size = len(doc[:-1]) - 1
    for token in doc[:-1]:
      emptyCondition = parragraphsText != ""
      pointsConditions = (token.text != "..") and (token.text != "...")
      capitalizeCondition = capitalizeCompiler.search(token.text)
      startCondition = token.is_sent_start
      if  startCondition and capitalizeCondition and emptyCondition and pointsConditions:
          pattagraphlist.append(parragraphsText)
          parragraphsText = token.text
      else:
        parragraphsText = parragraphsText + " " + token.text
      if size == token.i:
        pattagraphlist.append(parragraphsText)
        
    return pattagraphlist

  def __get_parragraph_dataframe(self, linesDataFrame: ks.DataFrame,
                              pageNumberColumn: str = "page_number",
                              documentKeyColumn: str = "document_key") -> ks.DataFrame:
    pageNumberList = []
    keyList = []
    textList = []
    parraphNumbersList = []
    nlp = SpacyTools.get_custom_spacy_pipeline()
    for idx, text in enumerate(linesDataFrame["concatenated_text"].to_numpy()):
      pageNumber = linesDataFrame.loc[idx, [pageNumberColumn]].values[0]
      key = linesDataFrame.loc[idx, [documentKeyColumn]].values[0]
      doc = nlp(text)
      parraphText = self.get_parraph_text(doc)
      size = len(parraphText)
      parraphNumbers = list(range(1, (size + 1))) 
      pageNumberList.extend([pageNumber] * size)
      keyList.extend([key] * size)
      textList.extend(parraphText)
      parraphNumbersList.extend(parraphNumbers)
    
    return {"document_key": keyList,
            "page_number": pageNumberList,
              "parragraph_number": parraphNumbersList,
              "parraph_text": textList }
    
    
  def get_lines_parrgraph(self,linesDataFrame: DataFrame,
                          **kargs) -> ks.DataFrame:
    concatenatedData = self.concatenate_lines_information(linesDataFrame,
                                                          documentKeyColumn=kargs.get("documentKeyColumn", "document_key"),
                                                          pageNumberColumn=kargs.get("pageNumberColumn", "page_number"),
                                                          textLinesColumn=kargs.get("textLinesColumn", "text_lines") )
    dictInformacion = self.__get_parragraph_dataframe(concatenatedData,
                                                    documentKeyColumn=kargs.get("documentKeyColumn", "document_key"),
                                                    pageNumberColumn=kargs.get("pageNumberColumn", "page_number"))
    
    return ks.DataFrame(dictInformacion)
  
  
  
class TableParrgraphsProcess:
  
  def __init__(self) -> None:
      pass
    
  def get_documents_information(self, spark: SparkSession,
                                queryDocumentInfo: str = """SELECT index, file_name, key 
                                                            FROM dbbronze.forms_metadata""") -> ks.DataFrame:
    metaData = ks.DataFrame(spark.sql(queryDocumentInfo))
    metaData['file_group'] = metaData.key.apply(lambda x: x.split('/')[1])
    metaData['file_type']  = metaData.key.apply(lambda x: x.split('/')[2])
    return metaData
    
    
  def save_delta_table(self, finalDataFrame:  ks.DataFrame,
                       spark: SparkSession,
                       deltaZonePath: str = "abfss://fscgrtextoliquido@sadiaritextoliquido.dfs.core.windows.net/delta/silver/",
                       **kargs):
    tableName = kargs.get("tableName", "documents")
    dataBase = kargs.get("dataBase", "dbsilver")
    completePath = deltaZonePath +  tableName + "/"
    finalDataFrame.to_delta(completePath, mode= kargs.get("saveMode", "append"))
    spark.sql(f"CREATE TABLE IF NOT EXISTS {dataBase}.{tableName} LOCATION '{completePath}'")
    spark.sql(f"REFRESH TABLE {dataBase}.{tableName}")
    
    
    
  def __get_parragraph_dataframe(self, spark: SparkSession,
                                 keyColumn: str = "key",
                                 queryDocumentTable: str = "SELECT key FROM dbbronze.documents_tables")-> ks.DataFrame:
    keyMetaData = ks.DataFrame(spark.sql(queryDocumentTable))
    for key in keyMetaData[keyColumn].unique().to_list():
        documentTable = ks.DataFrame(spark.sql(f"""SELECT column_index,row_index, is_header,
                                    text, counts_table, page_number FROM dbbronze.documents_tables
                                    WHERE key ='{key}' ORDER BY page_number,counts_table,row_index,column_index""")).spark.cache()
        textList=[]
        keyList=[]
        tableIndexList=[]
        for i in documentTable.page_number.unique().to_list():     
            for j in documentTable.counts_table.unique().to_list():
                #text1 = reduce(operator.add, df[(df.counts_table== j) & (df.page_number == i)].text.to_list())
                text1 = documentTable[(documentTable.counts_table== j) & (documentTable.page_number == i)].text.to_list()
                text = " ".join(text1)
                textList.append(text)
                keyList.append(key)
                tableIndexList.append(f"tabla_{j}_pag_{i}")        
        documentTable.unpersist()
        dicKey = {"label" : tableIndexList, "value" : textList, "key" : keyList}
        temporalData = ks.DataFrame(dicKey) 
        if 'finalDataFrame' in locals():
            finalDataFrame = ks.concat([finalDataFrame, temporalData])
        else:
            finalDataFrame = temporalData.copy()
    return finalDataFrame
            
  def clean_table_string(self, spark: SparkSession)-> None:
    spark.sql("DELETE FROM dbsilver.field_documents WHERE value = ''")
    spark.sql("DELETE FROM dbsilver.field_documents WHERE value LIKE 'C_DIGO%' or value LIKE 'C_digo%'")
    
  def get_tables_parrgraph(self, spark: SparkSession,
                           **kargs):
    documentsInformation = self.get_documents_information(spark,
                                                          kargs.get("queryDocumentInfo", 
                                                                    "SELECT index,file_name,key FROM dbbronze.forms_metadata"))
    self.save_delta_table(finalDataFrame = documentsInformation, 
                          spark=spark,
                          deltaZonePath=kargs.get("deltaZonePath", "abfss://fscgrtextoliquido@sadiaritextoliquido.dfs.core.windows.net/delta/silver/"),
                          tableName=kargs.get("tableName", "documents"),
                          dataBase = kargs.get("dataBase", "dbsilver"))
    
    return self.__get_parragraph_dataframe(spark=spark,
                                           queryDocumentTable = kargs.get("queryDocumentTable", 
                                                                          "SELECT key FROM dbbronze.documents_tables"))
  
