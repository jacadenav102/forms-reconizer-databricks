
from databricks.koalas import option_context
from pyspark.sql.functions import *

import databricks.koalas as ks


class ConfidenceTools:

    def __init__(self) -> None:
        pass
    
    def get_forms_confidence_score(self, reconizerFormsToDay: ks.DataFrame,
                                confidenceThreshold: float,
                                modelNameColumn: str = "model_name") -> ks.DataFrame:
        reconizerFormsToDay = reconizerFormsToDay.to_pandas()
        confidenceScore =  reconizerFormsToDay.groupby(modelNameColumn).quantile((confidenceThreshold))
        confidenceScore.reset_index(inplace=True)
        with option_context("compute.default_index_type", "distributed-sequence"):
            return ks.from_pandas(confidenceScore)


    def get_valid_forms_list(self, confidenceScore: ks.DataFrame,
                            validLabelThreshold: float,
                            confidenceColumn: str = "confidence",
                            modelNameColumn: str = "model_name") -> object:
        validForms = confidenceScore.loc[confidenceScore[confidenceColumn] <= ( 1 - validLabelThreshold), [modelNameColumn]]
        invalidFroms = confidenceScore.loc[confidenceScore[confidenceColumn] > (1 - validLabelThreshold), [modelNameColumn]]
        correctFormsList = validForms[modelNameColumn].unique().to_numpy().tolist()
        incorrectFormsList = invalidFroms[modelNameColumn].unique().to_numpy().tolist()
        
        return correctFormsList, incorrectFormsList



    def get_valid_invalid_forms_data(self,reconizerFormsToDay: ks.DataFrame,
                                    confidenceThreshold: float,
                                    validLabelThreshold: float,
                                    confidenceColumn: str = "confidence",
                                    modelNameColumn: str = "model_name",
                                    ) -> object:
        confidenceScore = self.get_forms_confidence_score(reconizerFormsToDay, confidenceThreshold,modelNameColumn)
        correctFormsList, incorrectFormsList  = self.get_valid_forms_list(confidenceScore, validLabelThreshold, confidenceColumn)
        
        
    
        return correctFormsList, incorrectFormsList 

    def execute_get_valid_form_list(self, reconizerFormsToDay: ks.DataFrame,
                                    confidenceThreshold: float,
                                    validLabelThreshold: float,
                                    confidenceColumn: str = "confidence",
                                    modelNameColumn: str = "model_name",
                                    ) -> object:
 
        confidenceScore = self.get_forms_confidence_score(reconizerFormsToDay, confidenceThreshold, modelNameColumn)
        correctFormsList, incorrectFormsList  = self.get_valid_forms_list(confidenceScore, validLabelThreshold, confidenceColumn)
        
        
    
        return correctFormsList, incorrectFormsList 



    def get_valid_invalid_forms_data(self, reconizerFormsToDay: ks.DataFrame,
                                    validLabelThreshold: float,
                                    confidenceThreshold: float,
                                    confidenceColumn: str = "confidence",
                                    modelNameColumn: str = "model_name"):
        correctFormsList, incorrectFormsList  = self.execute_get_valid_form_list(reconizerFormsToDay, validLabelThreshold,
                                                                            confidenceThreshold, confidenceColumn, modelNameColumn)
        invalidFormsTable = reconizerFormsToDay.loc[reconizerFormsToDay[modelNameColumn].isin(incorrectFormsList)]
        validFormsTable = reconizerFormsToDay.loc[reconizerFormsToDay[modelNameColumn].isin(correctFormsList)]

        return validFormsTable, invalidFormsTable

    def recover_correc_label_invalidforms(self, invalidFormsTable: ks.DataFrame,
                                        validFormsTable: ks.DataFrame,
                                    confidenceThreshold: float,
                                    confidenceColumn: str = "model_name") -> ks.DataFrame:
        toSaveFilter = invalidFormsTable[confidenceColumn] >= confidenceThreshold
        toSaveResults = invalidFormsTable.loc[toSaveFilter]
        validFormsTable = validFormsTable.append(toSaveResults)
        
        
        return validFormsTable




class SearchStateTools:
  
    def __init__(self) -> None:
      pass

    def get_found_labels(self, keyValuesData: ks.DataFrame,
                            searchedWordsDict: dict,
                        labelColumName: str = "label",
                        modelColumnName: str = "model_name") -> ks.DataFrame:
        foundenLabels = ks.DataFrame(columns=[labelColumName, "value", "confidence", modelColumnName, "key", "model_id"])
        for key, value in searchedWordsDict.items():
            modelSample = keyValuesData.loc[keyValuesData[modelColumnName].str.contains(key)]
            lowerValue = [string.lower() for string in value]
            foundenLabelsRows = modelSample.loc[modelSample[labelColumName].str.lower().isin(lowerValue)]
            foundenLabels = foundenLabels.append(foundenLabelsRows)
        return foundenLabels

    def get_count_documnet_model(self,keyValueTable: ks.DataFrame,
                                keyColumnName: str = "key",
                                modelColumnName: str = "model_name") -> ks.DataFrame:
        subsetData = keyValueTable.drop_duplicates(subset=[keyColumnName]).sort_index()
        countDocumentsModels =  subsetData.groupby(modelColumnName).count()[keyColumnName]
        return countDocumentsModels


    def get_count_found_labels(self,FoundsLabels: ks.DataFrame,
                            keyColumnName: str = "key",
                            modelColumnName: str = "model_name") -> ks.DataFrame:
        countedModelFounds = FoundsLabels.groupby([modelColumnName]).count()[keyColumnName]
        return countedModelFounds

    def get_state_search(self,countDocumentsModels: ks.DataFrame,
                        countedModelFounds: ks.DataFrame,
                        searchedWordsDict: dict) -> dict:
        completedSearchList = []
        modelList = []
        for model in countDocumentsModels.index.to_numpy():
            if model not in countedModelFounds.index.to_list():
                state = False
            else:
              keyToverify = [key for key in searchedWordsDict.keys() if(key in model)]
              for key in keyToverify:
                numberWords = len(searchedWordsDict.get(key))
                state = countedModelFounds.loc[model] == countDocumentsModels.loc[model] * numberWords
            modelList.append(model)
            completedSearchList.append(state)

        return {"model_name": modelList,
                "completed_search": completedSearchList}

    def get_state_search_data(self,
                            keyValueTable: ks.DataFrame,
                            searchedWordsDict: dict) -> ks.DataFrame:
        foundsLabels = self.get_found_labels(keyValueTable, searchedWordsDict)
        countedModelFounds = self.get_count_found_labels(foundsLabels)
        countDocumentsModels = self.get_count_documnet_model(keyValueTable)
        statesDict = self.get_state_search(countDocumentsModels, countedModelFounds, searchedWordsDict)
        return ks.DataFrame(statesDict)
