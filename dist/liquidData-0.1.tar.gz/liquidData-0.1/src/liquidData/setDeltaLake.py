from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils

import pandas as pd

import datetime
import IPython
import time
import os



class PrepareDBEnviroment:


    def __init__(self, spark: SparkSession,
                 zoneTime: str = "America/Bogota") -> None:
        self.dbutils = self.get_dbutils(spark)
        self.set_datetime_zone(zoneTime)

    def set_datetime_zone(self, zoneTime: str = "America/Bogota") -> None:
        os.environ['TZ'] = zoneTime
        time.tzset()
        
    def get_dbutils(self, spark: SparkSession):
        try:

            dbutils = DBUtils(spark)
        except ImportError:

            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils

    def set_enviroment_variables(self,
                                 adlsContainerName: str,
                                adlsAccountName: str,
                                dbbronze: str,
                                dbSilver: str,
                                dbGold: str,
                                authenticationKey: str,
                                applicationId: str,
                                directoryId: str,
                                adlsFolderName: str = "") -> None:
        os.environ["adlsContainerName"] =  adlsContainerName
        os.environ["adlsFolderName"] = adlsFolderName
        os.environ["adlsAccountName"] = adlsAccountName
        os.environ["mountPoint"] = "/mnt/" +  adlsContainerName
        os.environ["dbBronze"] = dbbronze
        os.environ["dbSilver"] = dbSilver
        os.environ["dbGold"] = dbGold
        os.environ["rootPath"] = "/dbfs" + os.environ["mountPoint"]
        os.environ["goldPath"] =  os.environ["rootPath"] + "/delta/Bronze/"
        os.environ["silverPath"] =  os.environ["rootPath"] + "/delta/Silver/"
        os.environ["goldPath"] =  os.environ["rootPath"]+ "/delta/Gold/"
        os.environ["authenticationKey"] = authenticationKey
        os.environ["applicationId"] = applicationId
        os.environ["directoryId"] = directoryId
        self.enviromentVariables = dict(os.environ)

    def get_secrets(self, configDict: dict) -> None:
        
        self.applicationId = self.dbutils.secrets.get(scope=configDict.get("secretsVault"), key=configDict.get("appIdSecret"))
        self.authenticationKey = self.dbutils.secrets.get(scope=configDict.get("secretsVault"), key=configDict.get("appPasswodSecret"))
        self.directoryId = self.dbutils.secrets.get(scope=configDict.get("secretsVault"), key=configDict.get("appDirectorySecret"))
        

    def set_delta_engine(self,
                    adlsAccountName: str,
                    applicationId: str,
                    authenticationKey: str,
                    directoryId: str,
                    dataLakeKey: str,
                    sparkToUse: SparkSession)-> None:
        sparkToUse.conf.set(f"fs.azure.account.auth.type.{adlsAccountName}.dfs.core.windows.net", "OAuth")
        sparkToUse.conf.set(f"fs.azure.account.oauth.provider.type.{adlsAccountName}.dfs.core.windows.net",  "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
        sparkToUse.conf.set(f"fs.azure.account.oauth2.client.id.{adlsAccountName}.dfs.core.windows.net", applicationId)
        sparkToUse.conf.set(f"fs.azure.account.oauth2.client.secret.{adlsAccountName}.dfs.core.windows.net", authenticationKey)
        sparkToUse.conf.set(f"fs.azure.account.oauth2.client.endpoint.{adlsAccountName}.dfs.core.windows.net", f"https://login.microsoftonline.com/{directoryId}/oauth2/token")
        sparkToUse.conf.set (f"fs.azure.account.key.{adlsAccountName}.dfs.core.windows.net", dataLakeKey)
        
    
    def set_start_configuration(self,
                               sparkToUse: SparkSession,
                               adlsContainerName: str,
                               adlsAccountName: str,
                               dbbronze: str,
                               dbSilver: str,
                               dbGold: str,
                               authenticationKey: str = None,
                               applicationId: str = None,
                               directoryId: str = None,
                               adlsFolderName: str = "") -> None:
        
        if authenticationKey is not None:
            importedAuthenticationKey = authenticationKey
        else:
            importedAuthenticationKey = self.authenticationKey
        if applicationId is not None:
            importedApplicationId = applicationId
        
        else:
            importedApplicationId = self.applicationId
            
        if directoryId is not None:
            importedDirectoryId = directoryId
        else:
            importedDirectoryId = self.directoryId
        self.set_enviroment_variables(adlsContainerName,
                                 adlsAccountName,
                                 dbbronze,
                                 dbSilver,
                                 dbGold,
                                 importedAuthenticationKey,
                                 importedApplicationId,
                                 importedDirectoryId,
                                 adlsFolderName)
        
        self.set_delta_engine(self.enviromentVariables.get("adlsAccountName"),
                              self.enviromentVariables.get("applicationId"),
                              self.enviromentVariables.get("directoryId"),
                              sparkToUse)
    
    
    
    
        self.mount_database(self.enviromentVariables.get("mountPoint"),
                            self.enviromentVariables.get("adlsContainerName"),
                            self.enviromentVariables.get("adlsContainerName"),
                            importedApplicationId,
                            importedAuthenticationKey,
                            importedDirectoryId)
    
    def mount_database(self, toMountPoint:str,
                       adlsContainerName: str,
                       adlsAccountName: str,
                       applicationId: str,
                       authenticationKey:str,
                       directoryId: str) -> None:
        
        if not any(mount.mountPoint == toMountPoint for mount in self.dbutils.fs.mounts()):
            try:
                endpoint = "https://login.microsoftonline.com/" + directoryId + "/oauth2/token"
                configs = {"fs.azure.account.auth.type": "OAuth",
                "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
                "fs.azure.account.oauth2.client.id": applicationId,
                "fs.azure.account.oauth2.client.secret": authenticationKey,
                "fs.azure.account.oauth2.client.endpoint": endpoint}
            
                source = f"abfss://{adlsContainerName}@{adlsAccountName}.dfs.core.windows.net/"
            
                self.dbutils.fs.mount(
                source = source,
                mount_point = toMountPoint,
                extra_configs = configs)
            except Exception:
              print(f"{toMountPoint} ya se encuentra montado.")  
        else:
            print(f"{toMountPoint} ya se encuentra montado.")

