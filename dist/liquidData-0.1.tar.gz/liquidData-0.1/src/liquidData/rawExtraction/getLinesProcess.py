from azure.ai.formrecognizer import FormRecognizerClient
import databricks.koalas as ks


class DocumentLinesProcess:

    def __init__(self) -> None:
        pass


    def get_lines_text_dict(self, documentResult: list,
                            documentKey: str) -> dict:
        if documentResult[0] == "NaN":
          return {"document_key": documentKey, "page_number": None, "text_angle": None, "line_number": None,
                    "text_lines": "NaN", "x_0": None, "y_0": None, "x_1": None, "y_1": None, "x_2": None,
                    "y_2": None, "x_3": None, "y_3": None}
        
        elif documentResult == "":
            return {"document_key": documentKey, "page_number": None, "text_angle": None, "line_number": None,
                    "text_lines": "NaN", "x_0": None, "y_0": None, "x_1": None, "y_1": None, "x_2": None,
                    "y_2": None, "x_3": None, "y_3": None}
        
        elif documentResult is None:
            return {"document_key": documentKey, "page_number": None, "text_angle": None, "line_number": None,
                    "text_lines": "NaN", "x_0": None, "y_0": None, "x_1": None, "y_1": None, "x_2": None,
                    "y_2": None, "x_3": None, "y_3": None}
        else:
            try:
                
                documentKeyList = []
                pageNumberList = []
                textAngleList = []
                actualLineNumberList = []
                boundingBoxX0List = []
                boundingBoxX1List = []
                boundingBoxX2List = []
                boundingBoxX3List = []
                boundingBoxY0List = []
                boundingBoxY1List = []
                boundingBoxY2List = []
                boundingBoxY3List = []
                lineTestList = []
                lineNumber = 1
                for pages in documentResult:
                    for lines in pages.lines:
                        boundingBox = lines.bounding_box
                        documentKeyList.append(documentKey)
                        pageNumberList.append(pages.page_number)
                        actualLineNumberList.append(lineNumber)
                        textAngleList.append(pages.text_angle)
                        boundingBoxX0List.append(boundingBox[0].x)
                        boundingBoxX1List.append(boundingBox[1].x)
                        boundingBoxX2List.append(boundingBox[2].x)
                        boundingBoxX3List.append(boundingBox[3].x)
                        boundingBoxY0List.append(boundingBox[0].y)
                        boundingBoxY1List.append(boundingBox[1].y)
                        boundingBoxY2List.append(boundingBox[2].y)
                        boundingBoxY3List.append(boundingBox[3].y)
                        lineTestList.append(lines.text)
                        lineNumber += 1
                

                
                
                return {"document_key": documentKeyList, "page_number": pageNumberList, "text_angle": textAngleList,
                    "line_number": actualLineNumberList, "text_lines": lineTestList, "x_0": boundingBoxX0List,
                        "y_0": boundingBoxY0List, "x_1": boundingBoxX1List, "y_1": boundingBoxY1List,
                    "x_2": boundingBoxX2List, "y_2": boundingBoxY2List, "x_3": boundingBoxX3List, "y_3": boundingBoxY3List}
            except:
                return {"document_key": documentKey, "page_number": None, "text_angle": None, "line_number": None,
                    "text_lines": "NaN", "x_0": None, "y_0": None, "x_1": None, "y_1": None, "x_2": None,
                    "y_2": None, "x_3": None, "y_3": None}

    def create_row_lines_document(self, documentResult: list,
                                  documentKey: str = "key") -> dict:
        if documentResult is not None:
            return self.get_lines_text_dict(documentResult, documentKey)
        else:
            return{"document_key": documentKey, "page_number": None, "text_angle": None, "line_number": None,
                    "text_lines": "NaN", "x_0": None, "y_0": None, "x_1": None, "y_1": None, "x_2": None,
                    "y_2": None, "x_3": None, "y_3": None}

    def get_document_result(self, formPath: str,
                            formClient: FormRecognizerClient,
                            pagesRange: str = "1-3",
                            contentFormatType: str = "application/pdf")-> list:

        
            try:
              with open(formPath, "rb") as fp:
                poolerResult = formClient.begin_recognize_content(form=fp.read(),
                                                                 pages=[pagesRange],
                                                                 content_type=contentFormatType)
            
              documentResult = poolerResult.result()
              return documentResult
            except Exception as exc:
              print(exc)
        
    def create_data_row_lines_document(self, documentResult: list, documentKey: str = "key") -> ks.DataFrame:
        documentLinesDict = self.create_row_lines_document(documentResult, documentKey)
        dictionarySize = len(documentLinesDict.get("document_key"))
        return ks.DataFrame(documentLinesDict, index=list(range(dictionarySize)))
        
    def get_total_documents_lines(self,
                                  formsMetaData: ks.DataFrame,
                                  formRecognizer: FormRecognizerClient,
                                  documentKeyColum: str = "key",
                                  documentPathColumn: str = "file_path",
                                  pagesRange: str = "1-3",
                                  contentFormatType: str = "application/pdf") -> ks.DataFrame:
        copyData = formsMetaData.reset_index()
        emptyDataFrame = ks.DataFrame(columns=['document_key', 'page_number', 'text_angle',
                      'line_number', 'text_lines', 'x_0', 'y_0', 'x_1', 'y_1', 
                      'x_2', 'y_2', 'x_3', 'y_3'])
        for idx, pathDocument in enumerate(copyData[documentPathColumn].to_numpy()):
            keyDocument = copyData.loc[idx, [documentKeyColum]][0]
            formResult = self.get_document_result(pathDocument, formRecognizer, pagesRange, contentFormatType)
            documentLinesSeries = self.create_data_row_lines_document(formResult, keyDocument)
            emptyDataFrame = emptyDataFrame.append(documentLinesSeries, ignore_index=True)
        return emptyDataFrame