from azure.ai.formrecognizer import FormRecognizerClient
import databricks.koalas as ks


class ExtractionTableProcess:
  def __init__(self) -> None: 
  
  
    pass 
  
  
  def get_table_info_dict(self, formPages: list) -> dict:
      columnIndexList = []
      rowIndexList = []
      textList = []
      page_number = []
      x0List = []
      x1List = []
      x2List = []
      x3List = []
      y0List = []
      y1List = []
      y2List = []
      y3List = []
      countsTableList=[]
      isHeaderList = []
      isFooterList = []
      key = formPages[-1]
      formPages = formPages[:-1]
      for content in formPages:
        count_table = 0
        for table in content.tables:
          count_table += 1          
          for cell in table.cells:
            columnIndexList.append(cell.column_index)
            rowIndexList.append(cell.row_index)
            textList.append(cell.text)
            page_number.append(cell.page_number)
            isHeaderList.append(cell.is_header)
            isFooterList.append(cell.is_footer)
            x0List.append(cell.bounding_box[0].x)
            x1List.append(cell.bounding_box[1].x)
            x2List.append(cell.bounding_box[2].x)
            x3List.append(cell.bounding_box[3].x)
            y0List.append(cell.bounding_box[0].y)
            y1List.append(cell.bounding_box[1].y)
            y2List.append(cell.bounding_box[2].y)
            y3List.append(cell.bounding_box[3].y)
            countsTableList.append(count_table)
            
      return {"column_index": columnIndexList, 
              "row_index": rowIndexList,
              "text": textList,
              "page_number": page_number,
               "x_0": x0List,
               "y_0": y0List, "x_1": x1List , "y_1": y1List,
               "x_2": x2List , "y_2": y2List, "x_3": x3List, "y_3": y3List,
               "counts_table": countsTableList, "is_header": isHeaderList, "is_footer": isFooterList, "key" : key}    
    
  def get_df_table_info(self, formPages: list) -> ks.DataFrame:
    infotable_dict = self.get_table_info_dict(formPages)
    infotable_dict = ks.DataFrame(infotable_dict)
    return infotable_dict  


  def get_total_document_tabler(self,
                                formsMetaData: ks.DataFrame,
                                formRecognizerClient: FormRecognizerClient,
                                **kargs):
    for document,key in zip(formsMetaData[kargs.get("filePathColumn", 'file_path')].to_numpy(),
                            formsMetaData[kargs.get("keyColumn", 'key')].to_numpy()):
      withoutExtractionList = []
      with open(document, "rb") as fp:
        form = fp.read()
      pooleResult = formRecognizerClient.begin_recognize_content(form).result()
      pooleResult.append(str(key))
      temporalData = self.get_df_table_info(pooleResult)
      if 'documentTables' in locals():
        try:
          ks.concat([documentTables, documentTables])
          
        except:
          withoutExtractionList.append(key)
        
      else:
        documentTables = temporalData.copy()
        
    return documentTables