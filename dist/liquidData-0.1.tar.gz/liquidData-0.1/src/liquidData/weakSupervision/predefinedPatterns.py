patternDict = {"nitPattern": [
  {"ENT_TYPE": {"IN": ["PER", "ORG"] }, "OP": "?"},
  {"ENT_TYPE": {"IN": ["PER", "ORG"] }, "OP": "?"},
  {"LEMMA": "identificado", "OP": "?"}, {"TAG": "ADP"},
  {"LOWER": "nit"}, {"POS": "PUNCT", "OP": "?"},  
  {"POS":{"IN": ["SYM", "NUM", "NOUN"]}}, 
  {"ENT_TYPE": {"IN": ["PER", "ORG"]}, "OP":"?"}],
  "cedulaPattern": [
    {"ENT_TYPE": {"IN": ["PER", "ORG"] }, "OP": "?"},
    {"ENT_TYPE": {"IN": ["PER", "ORG"] }, "OP": "?"},
    {"LEMMA": "identificado"}, {"TAG": "ADP", "OP": "?"}, {"LOWER":{"IN": ["cedula", "cédula"]}},
    {"POS": "ADP", "OP": "?"}, {"POS": { "IN": ["NOUN", "ADV "]}, "OP": "?"},
    {"LOWER": {"IN" : ["ciudadanía", "ciudadanía"]}, "OP": "?" }, 
    {"POS": { "IN": ["NOUN", "ADV"]}, "OP": "?"}, {"TAG": "PUNCT", "OP": "?"},
    {"POS":{"IN" : ["NUM", "SYM", "NOUN"]}}, {"ENT_TYPE": {"IN": ["PER", "ORG"]}, "OP":"?"}
      ] }