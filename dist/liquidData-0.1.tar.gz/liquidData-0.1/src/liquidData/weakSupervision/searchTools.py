from snorkel.labeling.lf.nlp import nlp_labeling_function
from snorkel.preprocess.nlp import SpacyPreprocessor
from snorkel.labeling import LabelingFunction
from dateutil.parser import parse
from datetime import datetime

import pandas as pd
import re


class DateTools:

  @staticmethod
  def get_regex_date(string: str) ->bool:
    compiler = re.compile("([0-9]){2}\s(de)\s([a-z]){3,10}\s(del|de)\s([0-9]){4}")
    if compiler.search(string):
      return True
    else:
      return False
  
  @staticmethod  
  def check_datetime_valid_date(string: str) -> bool:
    for formats in ["%d/%m/%y", "%d/%m/%yyyy", "%d-%m-%yyyy", "%d-%m-%y", "d-%b-%y", "d-%b-%yyyy", "%d %m %yyyy"]:
      try:
        datetime.strptime(string, formats )
        return True
      except:
        return False
  
  @staticmethod
  def check_valid_date(string: str, fuzzy: bool=False) -> bool:
    try:
      parse(string, fuzzy)
      return True
    except:
      return False

class SearchTools:

  @staticmethod
  def return_check_person_function(spacyProcessor: SpacyPreprocessor,
                                  textFielCoulmn: str,
                                  label: int,
                                  **kwargs) -> object:

    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))
    
    def check_person(x):
      if any([ent.label_ == "PER" for ent in x.doc.ents]):
        return label
      else:
        return -1  
      
    return check_person

  @staticmethod
  def return_check_place_function(spacyProcessor: SpacyPreprocessor,
                                  textFielCoulmn: str,
                                  label: int,
                                  **kwargs) -> object:

    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))

    def check_place(x):
      if any([ent.label_ == "LOC" for ent in x.doc.ents]):
        return label
      else:
        return -1  

    return check_place

  @staticmethod
  def return_check_money_function(spacyProcessor: SpacyPreprocessor,
                                  textFielCoulmn: str,
                                  label: int,
                                  **kwargs) -> object:

    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))

    def check_money(x):
      if any([ent.label_ == "MONEY" for ent in x.doc.ents]):
        return label
      else:
        return -1
      
    return check_money

  @staticmethod
  def return_check_organization_function(spacyProcessor: SpacyPreprocessor,
                                  textFielCoulmn: str,
                                  label: int,
                                  **kwargs) -> object:

    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))
    def check_organization(x):
      if any([ent.label_ == "ORG" for ent in x.doc.ents]):
        return label
      else:
        return -1 
      
    return check_organization
    
  @staticmethod
  def generic_keyword_percentage_lookup(x: pd.DataFrame,
                                      textColumnName: str,
                                      keywordsList: list,
                                      label: object) -> int:
    compiler = re.compile("\d+(\%|\s\bpercent\b)")
    LString = x[textColumnName].lower()
    matched_list = [LString.count(characters) for characters in keywordsList]
    if matched_list[0] is not None:
      wordsCondition =  any([i > 0 for i in matched_list])
      if compiler.search(LString) and wordsCondition:
        return label
      else:
        return -1
    else:
      return -1
    
  @staticmethod
  def generic_keyword_percentage_lookup(x: pd.DataFrame,
                                      textColumnName: str,
                                      keywordsList: list,
                                      label: object) -> int:
    compiler = re.compile("\d+(\%|\s\bpercent\b)")
    LString = x[textColumnName].lower()
    matched_list = [LString.count(characters) for characters in keywordsList]
    if matched_list[0] is not None:
      wordsCondition =  any([i > 0 for i in matched_list])
      if compiler.search(LString) and wordsCondition:
        return label
      else:
        return -1
    else:
      return -1
    
  @staticmethod
  def generic_keyword_lookup(x: pd.DataFrame,
                           textColumnName: str,
                           keywordsList: list,
                           label: object) -> int:
    LString = x[textColumnName].lower()
    matched_list = [LString.count(characters) for characters in keywordsList]
    if matched_list[0] is not None:
      wordsCondition =  any([i > 0 for i in matched_list])
      if wordsCondition:
        return label
      else:
        return -1
    else:
      return -1
    
    
  @staticmethod    
  def generic_keyword_date_lookup(x: pd.DataFrame,
                                textColumnName: str,
                                keywordsList: list,
                                label: object) -> int:

    LString = x[textColumnName].lower()
    matched_list = [LString.count(characters) for characters in keywordsList]
    if matched_list[0] is not None:
      wordsCondition =  any([i > 0 for i in matched_list])
      validDateConditionOne = any([ DateTools.check_valid_date(i)  for i in LString.split()])
      validDateConditionTwo = DateTools.get_regex_date(LString)
      if wordsCondition and (validDateConditionOne or validDateConditionTwo):
        return label
      else:
        return -1
    else:
      return -1
    
    
  @staticmethod
  def return_check_org_id(spacyProcessor: SpacyPreprocessor,
                          textFielCoulmn: str,
                          label: int,
                          **kwargs) -> object:
    
    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))
    
    def check_org_id(x) -> int:
      org_presence = any([ent.label_ == "ORG" for ent in x.doc.ents])
      if org_presence:
        identificado_presence = any([tok.text.lower() == "identificado" for tok in x.doc])
        nit_presence = any([tok.text.lower() == "nit" for tok in x.doc])
        if identificado_presence and  nit_presence:
          return label
        else:
          return -1
      else:
        return -1
      
    return check_org_id
  
  @staticmethod
  def return_check_org_id_completed(spacyProcessor: SpacyPreprocessor,
                                    textFielCoulmn: str,
                                    label: int,
                                    **kwargs) -> object:
  
    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))
  
    def check_org_id_completed(x) -> int:
      org_presence = any([ent.label_ == "ORG" for ent in x.doc.ents])
      if org_presence:
        identificado_presence = any([tok.text.lower() == "identificado" for tok in x.doc])
        nit_presence = any([tok.text.lower() == "nit" for tok in x.doc])
        not_empty = (re.search(r'(?<=no\.)[^.\s]*', x.doc.text) or re.search(r'(?<= Nº)[^.\s]*', x.doc.text))
        if identificado_presence and  nit_presence and not_empty:
          return label
        else:
          return -1     
      else:
        return -1
      
    return check_org_id_completed
  
  def return_check_person_id(spacyProcessor: SpacyPreprocessor,
                             textFielCoulmn: str,
                             label: int,
                             **kwargs) -> object:
    
    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))
    
    def check_person_id(x) -> int:
      person_presence = any([ent.label_ == "PER" for ent in x.doc.ents])
      represent_presence = any([tok.text.lower() == "representante" for tok in x.doc])
      if  person_presence or represent_presence:
        identificado_presence = any([tok.text.lower() == "identificado" for tok in x.doc])
        cedula_precense = any([tok.text.lower() == "cedula" for tok in x.doc])
        if identificado_presence and cedula_precense:
          return label
        else:
          return -1
      
      else:
        return -1
      
    return check_person_id
      
  def return_check_completed_person_id(spacyProcessor: SpacyPreprocessor,
                                       textFielCoulmn: str,
                                       label: int,
                                       **kwargs) -> object:
    
    @nlp_labeling_function(pre=[spacyProcessor], text_field=textFielCoulmn, doc_field=kwargs.get("docFiels", "doc"),
                          memoize=kwargs.get("memoize", True), language=kwargs.get("spacyLanguage", "es_core_news_lg"))
    
    def check_person_id_completed(x):
      person_presence = any([ent.label_ == "PER" for ent in x.doc.ents])
      represent_presence = any([tok.text.lower() == "representante" for tok in x.doc])
      if person_presence or represent_presence:
        identificado_presence = any([tok.text.lower() == "identificado" for tok in x.doc])
        cedula_precense = any([tok.text.lower() == "cedula" for tok in x.doc])
        not_empty = (re.search(r'(?<=no\.)[^.\s]*', x.doc.text) or re.search(r'(?<= Nº)[^.\s]*', x.doc.text))
        if identificado_presence and cedula_precense and not_empty:
          return label
        else:
          return -1
      
      else:
        return -1
      
    return check_person_id_completed
      
class FunctionCreator:      
  @staticmethod
  def make_keyword_lf(functionName: str,
                      keywordsList: list,
                      label: object,
                      textColumnName: str) -> LabelingFunction:
      return LabelingFunction(
                              name=f"keyword_{functionName.strip()}",
                              f=SearchTools.generic_keyword_lookup,
                              resources=dict(keywordsList=keywordsList, label=label, textColumnName=textColumnName),
  )
    
    
  @staticmethod
  def make_keyword_percentage_lf(functionName: str,
                               keywordsList: list,
                               label: object,
                               textColumnName: str) -> LabelingFunction:
    return LabelingFunction(
                            name=f"keyword_percentage_{functionName.strip()}",
                            f=SearchTools.generic_keyword_percentage_lookup,
                            resources=dict(keywordsList=keywordsList, label=label, textColumnName=textColumnName)
    )
    
    
  @staticmethod
  def make_keyword_date_lf(functionName: str,
                               keywordsList: list,
                               label: object,
                               textColumnName: str) -> LabelingFunction:
    return LabelingFunction(
                            name=f"keyword_date_{functionName.strip()}",
                            f=SearchTools.generic_keyword_date_lookup,
                            resources=dict(keywordsList=keywordsList, label=label, textColumnName=textColumnName))

  
  
