from pyspark.sql.functions import col
from pyspark.sql.types import *

import databricks.koalas as ks
import pyspark
import pandas as pd

class ExportWeakResultProcess:
  
  def __init__(self) -> None:
      pass

  def convert_pandas_prediction(self, predictionDataFrame: pd.DataFrame,
                             pageNumberColumn: str = "page_number"):
  
    return (
    ks.DataFrame(predictionDataFrame).to_spark()
    .filter(col(pageNumberColumn).isNotNull())
    .withColumn(pageNumberColumn, col(pageNumberColumn).cast(LongType())))


  def  convert_prediction_column(self, sparkPredictionData: pyspark.sql.dataframe.DataFrame,
                               functionsDict: dict,
                               **kargs) -> object:
    
    return (sparkPredictionData
            .rdd
            .map(lambda x: (x[kargs.get("dcoumnetKeyColumn", "document_key")], 
                            x[kargs.get("pageNumberColumn","page_number")],
                            x[kargs.get("parragrpahNumberColumn","parragraph_number")],
                            x[kargs.get("textColumn","parraph_text")], 
                            functionsDict.get(x[kargs.get("predictionColumn","prediction")]))) )



  def create_schema_to_export(self):
    return StructType([StructField("key",StringType(),False),
                                 StructField("pag_n",LongType(),False),
                                 StructField("parrafo_n",LongType(),False),
                                 StructField("info_parrafo",StringType(),False),
                                 StructField("criterio_busqueda",StringType(),True)])



  def get_weak_prediction_table(self,predictionDataFrame: pd.DataFrame,
                              functionsDict:dict,
                             **kargs) -> object:
    sparkData = self.convert_pandas_prediction(predictionDataFrame, kargs.get("pageNumberColumn", "page_number"))
    rddtoExport = self.convert_prediction_column(sparkPredictionData=sparkData,
                                              functionsDict=functionsDict,
                                              dcoumnetKeyColumn=kargs.get("dcoumnetKeyColumn", "document_key"),
                                              pageNumberColumn=kargs.get("pageNumberColumn","page_number"),
                                              parragrpahNumberColumn=kargs.get("parragrpahNumberColumn","parragraph_number"),
                                              textColumn=kargs.get("textColumn","parraph_text"),
                                              predictionColumn=kargs.get("predictionColumn","prediction"))
    toExportSchema = self.create_schema_to_export()
    return rddtoExport.toDF(schema= toExportSchema)